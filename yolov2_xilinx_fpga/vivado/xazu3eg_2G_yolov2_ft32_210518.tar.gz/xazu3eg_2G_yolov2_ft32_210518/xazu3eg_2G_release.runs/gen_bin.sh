#!/bin/bash

source /tools/Xilinx/Vivado/2019.2/settings64.sh
rm design_1_wrapper.bit*
cp impl_1/design_1_wrapper.bit .
bootgen -image Full_Bitstream.bif -arch zynqmp -process_bitstream bin
mv design_1_wrapper.bit.bin design_1_wrapper_in256b.bin
